package com.svgu.p08.service;

import com.svgu.p08.entity.Product;
import org.springframework.data.domain.Page;

public interface ProductService {
    Page<Product> getProducts(int page, int size, String sortBy);
    Product create(Product product);
    Product update(int id, Product product);
    boolean delete(int id);
}
