package com.svgu.p08.repository;

import com.svgu.p08.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/** JpaRepository supports findAll(Pageable) for pagination. */
public interface ProductRepository extends JpaRepository<Product, Integer> {
}
