package com.svgu.p08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 8: Pagination and Sorting with Spring Data JPA.
 */
@SpringBootApplication
public class Practical08Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical08Application.class, args);
    }
}
