package com.svgu.p04.service;

import com.svgu.p04.entity.Employee;

import java.util.List;

public interface EmployeeService {
    Employee create(Employee employee);
    List<Employee> getAll();
    Employee getById(int id);
}
