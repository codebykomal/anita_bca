package com.svgu.p04.service;

import com.svgu.p04.entity.Country;

import java.util.List;

public interface CountryService {
    Country create(Country country);
    List<Country> getAll();
    Country getById(int id);
}
