package com.svgu.p04.service;

import com.svgu.p04.entity.User;

import java.util.List;

public interface UserService {
    User create(User user);
    List<User> getAll();
    User getById(int id);
    User update(int id, User user);
    boolean delete(int id);
}
