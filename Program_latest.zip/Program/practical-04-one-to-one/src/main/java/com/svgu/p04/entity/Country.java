package com.svgu.p04.entity;

import jakarta.persistence.*;

/** Example 3 - owning side of Country-Capital. */
@Entity
public class Country {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int countryId;

    private String countryName;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "capital_id")
    private Capital capital;

    public Country() {
    }

    public int getCountryId() { return countryId; }
    public void setCountryId(int countryId) { this.countryId = countryId; }
    public String getCountryName() { return countryName; }
    public void setCountryName(String countryName) { this.countryName = countryName; }
    public Capital getCapital() { return capital; }
    public void setCapital(Capital capital) { this.capital = capital; }
}
