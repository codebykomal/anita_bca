package com.svgu.p04.service.impl;

import com.svgu.p04.entity.User;
import com.svgu.p04.repository.UserRepository;
import com.svgu.p04.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User create(User user) {
        return userRepository.save(user); // cascade saves the profile too
    }

    @Override
    public List<User> getAll() {
        return userRepository.findAll();
    }

    @Override
    public User getById(int id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public User update(int id, User updated) {
        User user = userRepository.findById(id).orElse(null);
        if (user == null) {
            return null;
        }
        user.setUsername(updated.getUsername());
        user.setEmail(updated.getEmail());
        if (updated.getUserProfile() != null) {
            user.setUserProfile(updated.getUserProfile());
        }
        return userRepository.save(user);
    }

    @Override
    public boolean delete(int id) {
        if (!userRepository.existsById(id)) {
            return false;
        }
        userRepository.deleteById(id);
        return true;
    }
}
