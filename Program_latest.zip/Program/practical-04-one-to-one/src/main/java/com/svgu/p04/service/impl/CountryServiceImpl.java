package com.svgu.p04.service.impl;

import com.svgu.p04.entity.Country;
import com.svgu.p04.repository.CountryRepository;
import com.svgu.p04.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CountryServiceImpl implements CountryService {

    @Autowired
    private CountryRepository countryRepository;

    @Override
    public Country create(Country country) {
        return countryRepository.save(country); // cascade saves the capital too
    }

    @Override
    public List<Country> getAll() {
        return countryRepository.findAll();
    }

    @Override
    public Country getById(int id) {
        return countryRepository.findById(id).orElse(null);
    }
}
