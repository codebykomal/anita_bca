package com.svgu.p04.controller;

import com.svgu.p04.entity.Country;
import com.svgu.p04.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Example 3: Country - Capital. Controller calls the service only.
 *   POST   /api/countries        -> 201 Created
 *   GET    /api/countries        -> 200 OK
 *   GET    /api/countries/{id}
 */
@RestController
@RequestMapping("/api/countries")
public class CountryRestController {

    @Autowired
    private CountryService countryService;

    @PostMapping
    public ResponseEntity<Country> create(@RequestBody Country country) {
        return ResponseEntity.status(HttpStatus.CREATED).body(countryService.create(country));
    }

    @GetMapping
    public ResponseEntity<List<Country>> getAll() {
        return ResponseEntity.ok(countryService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Country> getById(@PathVariable int id) {
        Country country = countryService.getById(id);
        if (country == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(country);
    }
}
