package com.svgu.p04.controller;

import com.svgu.p04.entity.Employee;
import com.svgu.p04.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Example 2: Employee - Passport. Controller calls the service only.
 *   POST   /api/employees-passport        -> 201 Created
 *   GET    /api/employees-passport        -> 200 OK
 *   GET    /api/employees-passport/{id}
 */
@RestController
@RequestMapping("/api/employees-passport")
public class EmployeePassportController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping
    public ResponseEntity<Employee> create(@RequestBody Employee employee) {
        return ResponseEntity.status(HttpStatus.CREATED).body(employeeService.create(employee));
    }

    @GetMapping
    public ResponseEntity<List<Employee>> getAll() {
        return ResponseEntity.ok(employeeService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getById(@PathVariable int id) {
        Employee employee = employeeService.getById(id);
        if (employee == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(employee);
    }
}
