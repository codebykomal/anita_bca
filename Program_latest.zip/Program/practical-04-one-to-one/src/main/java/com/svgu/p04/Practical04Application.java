package com.svgu.p04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 4: One-to-One Mapping - Three Worked Examples.
 */
@SpringBootApplication
public class Practical04Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical04Application.class, args);
    }
}
