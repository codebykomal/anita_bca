package com.svgu.p14.controller;

import com.svgu.p14.entity.Employee;
import com.svgu.p14.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller calls the service only. A missing id makes the service throw
 * ResourceNotFoundException, which the GlobalExceptionHandler turns into a 404.
 *   POST   /api/employees        -> 201 Created
 *   GET    /api/employees/{id}   -> 200 OK (or 404 via handler)
 *   PUT    /api/employees/{id}   -> 200 OK (or 404 via handler)
 *   DELETE /api/employees/{id}   -> 204 No Content (or 404 via handler)
 */
@RestController
@RequestMapping("/api/employees")
public class EmployeeRestController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping
    public ResponseEntity<Employee> create(@RequestBody Employee employee) {
        return ResponseEntity.status(HttpStatus.CREATED).body(employeeService.create(employee));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getById(@PathVariable int id) {
        return ResponseEntity.ok(employeeService.getById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employee> update(@PathVariable int id, @RequestBody Employee updated) {
        return ResponseEntity.ok(employeeService.update(id, updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        employeeService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
