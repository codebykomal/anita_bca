package com.svgu.p14.service;

import com.svgu.p14.entity.Employee;

public interface EmployeeService {
    Employee create(Employee employee);
    Employee getById(int id);
    Employee update(int id, Employee employee);
    void delete(int id);
}
