package com.svgu.p14.service;

import com.svgu.p14.entity.Customer;

public interface CustomerService {
    Customer create(Customer customer);
}
