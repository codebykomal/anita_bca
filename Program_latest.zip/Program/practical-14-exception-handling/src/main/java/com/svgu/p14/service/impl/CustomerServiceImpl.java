package com.svgu.p14.service.impl;

import com.svgu.p14.entity.Customer;
import com.svgu.p14.repository.CustomerRepository;
import com.svgu.p14.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer create(Customer customer) {
        return customerRepository.save(customer);
    }
}
