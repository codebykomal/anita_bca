package com.svgu.p14.controller;

import com.svgu.p14.entity.Customer;
import com.svgu.p14.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Invalid data here triggers the validation handler in GlobalExceptionHandler,
 * which returns a 400 with field-wise error messages.
 *   POST /api/customers  @Valid -> 201 Created
 */
@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<Customer> create(@Valid @RequestBody Customer customer) {
        return ResponseEntity.status(HttpStatus.CREATED).body(customerService.create(customer));
    }
}
