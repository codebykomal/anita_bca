package com.svgu.p14.exception;

import java.time.LocalDateTime;

/** Structured error body returned to clients. */
public class ErrorResponse {

    private LocalDateTime timestamp;
    private String message;
    private int status;
    private String path;

    public ErrorResponse() {
    }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
}
