package com.svgu.p14.service.impl;

import com.svgu.p14.entity.Employee;
import com.svgu.p14.exception.ResourceNotFoundException;
import com.svgu.p14.repository.EmployeeRepository;
import com.svgu.p14.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service throws ResourceNotFoundException when an employee is not found.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Employee create(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public Employee getById(int id) {
        Employee employee = employeeRepository.findById(id).orElse(null);
        if (employee == null) {
            throw new ResourceNotFoundException("Employee not found with id: " + id);
        }
        return employee;
    }

    @Override
    public Employee update(int id, Employee updated) {
        Employee employee = getById(id); // throws if missing
        employee.setEmpName(updated.getEmpName());
        employee.setDepartment(updated.getDepartment());
        employee.setSalary(updated.getSalary());
        return employeeRepository.save(employee);
    }

    @Override
    public void delete(int id) {
        Employee employee = getById(id); // throws if missing
        employeeRepository.delete(employee);
    }
}
