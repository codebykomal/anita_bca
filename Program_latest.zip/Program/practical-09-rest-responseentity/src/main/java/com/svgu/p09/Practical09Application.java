package com.svgu.p09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 9: RESTful Microservice using @RestController and ResponseEntity.
 */
@SpringBootApplication
public class Practical09Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical09Application.class, args);
    }
}
