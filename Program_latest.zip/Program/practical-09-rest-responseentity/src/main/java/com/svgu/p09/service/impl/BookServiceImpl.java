package com.svgu.p09.service.impl;

import com.svgu.p09.entity.Book;
import com.svgu.p09.service.BookService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/** Service holds the in-memory book list (no database in this practical). */
@Service
public class BookServiceImpl implements BookService {

    private List<Book> store = new ArrayList<>();
    private int nextId = 1;

    @Override
    public Book create(Book book) {
        book.setId(nextId);
        nextId++;
        store.add(book);
        return book;
    }

    @Override
    public List<Book> getAll() {
        return store;
    }

    @Override
    public Book getById(int id) {
        for (Book book : store) {
            if (book.getId() == id) {
                return book;
            }
        }
        return null;
    }

    @Override
    public Book update(int id, Book updated) {
        for (Book book : store) {
            if (book.getId() == id) {
                book.setTitle(updated.getTitle());
                book.setAuthor(updated.getAuthor());
                book.setPrice(updated.getPrice());
                return book;
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        return store.removeIf(book -> book.getId() == id);
    }
}
