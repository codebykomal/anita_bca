package com.svgu.p09.service;

import com.svgu.p09.entity.Book;

import java.util.List;

public interface BookService {
    Book create(Book book);
    List<Book> getAll();
    Book getById(int id);
    Book update(int id, Book book);
    boolean delete(int id);
}
