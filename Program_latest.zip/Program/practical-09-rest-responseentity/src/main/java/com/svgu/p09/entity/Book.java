package com.svgu.p09.entity;

/** Plain POJO (no JPA), stored in an in-memory list inside the service. */
public class Book {

    private int id;
    private String title;
    private String author;
    private double price;

    public Book() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
}
