package com.svgu.p05.service;

import com.svgu.p05.entity.Department;
import com.svgu.p05.entity.Employee;

import java.util.List;

public interface DepartmentService {
    Department create(Department department);
    Department getById(int id);
    List<Employee> getEmployees(int deptId);
    Department rename(int id, Department department);
    Department updateEmployee(int deptId, int empId, Employee employee);
    boolean removeEmployee(int deptId, int empId);
    boolean delete(int id);
}
