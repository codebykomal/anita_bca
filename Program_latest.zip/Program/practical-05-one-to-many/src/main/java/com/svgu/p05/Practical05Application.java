package com.svgu.p05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 5: One-to-Many / Many-to-One Mapping - Department and Employee.
 */
@SpringBootApplication
public class Practical05Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical05Application.class, args);
    }
}
