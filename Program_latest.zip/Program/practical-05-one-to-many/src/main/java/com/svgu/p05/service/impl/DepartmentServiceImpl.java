package com.svgu.p05.service.impl;

import com.svgu.p05.entity.Department;
import com.svgu.p05.entity.Employee;
import com.svgu.p05.repository.DepartmentRepository;
import com.svgu.p05.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Override
    public Department create(Department department) {
        // link each employee to this department before saving the graph
        for (Employee e : department.getEmployees()) {
            e.setDepartment(department);
        }
        return departmentRepository.save(department);
    }

    @Override
    public Department getById(int id) {
        return departmentRepository.findById(id).orElse(null);
    }

    @Override
    public List<Employee> getEmployees(int deptId) {
        Department department = departmentRepository.findById(deptId).orElse(null);
        if (department == null) {
            return null;
        }
        return department.getEmployees();
    }

    @Override
    public Department rename(int id, Department updated) {
        Department department = departmentRepository.findById(id).orElse(null);
        if (department == null) {
            return null;
        }
        department.setDeptName(updated.getDeptName());
        return departmentRepository.save(department);
    }

    @Override
    public Department updateEmployee(int deptId, int empId, Employee updated) {
        Department department = departmentRepository.findById(deptId).orElse(null);
        if (department == null) {
            return null;
        }
        for (Employee e : department.getEmployees()) {
            if (e.getEmpId() == empId) {
                e.setEmpName(updated.getEmpName());
                e.setSalary(updated.getSalary());
            }
        }
        return departmentRepository.save(department);
    }

    @Override
    public boolean removeEmployee(int deptId, int empId) {
        Department department = departmentRepository.findById(deptId).orElse(null);
        if (department == null) {
            return false;
        }
        department.getEmployees().removeIf(e -> e.getEmpId() == empId);
        departmentRepository.save(department);
        return true;
    }

    @Override
    public boolean delete(int id) {
        if (!departmentRepository.existsById(id)) {
            return false;
        }
        departmentRepository.deleteById(id);
        return true;
    }
}
