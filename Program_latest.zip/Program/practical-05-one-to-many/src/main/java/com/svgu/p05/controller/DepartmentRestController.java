package com.svgu.p05.controller;

import com.svgu.p05.entity.Department;
import com.svgu.p05.entity.Employee;
import com.svgu.p05.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Department - Employee (One-to-Many / Many-to-One). Controller calls service only.
 *   POST   /api/departments                              -> 201 Created
 *   GET    /api/departments/{id}
 *   GET    /api/departments/{id}/employees
 *   PUT    /api/departments/{id}                         rename
 *   PUT    /api/departments/{deptId}/employees/{empId}   update employee
 *   DELETE /api/departments/{deptId}/employees/{empId}
 *   DELETE /api/departments/{id}
 */
@RestController
@RequestMapping("/api/departments")
public class DepartmentRestController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping
    public ResponseEntity<Department> create(@RequestBody Department department) {
        return ResponseEntity.status(HttpStatus.CREATED).body(departmentService.create(department));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Department> getById(@PathVariable int id) {
        Department department = departmentService.getById(id);
        if (department == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(department);
    }

    @GetMapping("/{id}/employees")
    public ResponseEntity<List<Employee>> getEmployees(@PathVariable int id) {
        List<Employee> employees = departmentService.getEmployees(id);
        if (employees == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(employees);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Department> rename(@PathVariable int id, @RequestBody Department updated) {
        Department department = departmentService.rename(id, updated);
        if (department == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(department);
    }

    @PutMapping("/{deptId}/employees/{empId}")
    public ResponseEntity<Department> updateEmployee(@PathVariable int deptId,
                                                     @PathVariable int empId,
                                                     @RequestBody Employee updated) {
        Department department = departmentService.updateEmployee(deptId, empId, updated);
        if (department == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(department);
    }

    @DeleteMapping("/{deptId}/employees/{empId}")
    public ResponseEntity<Void> removeEmployee(@PathVariable int deptId, @PathVariable int empId) {
        boolean removed = departmentService.removeEmployee(deptId, empId);
        if (!removed) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = departmentService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
