package com.svgu.p07.exception;

/** Custom unchecked exception that triggers @Transactional rollback. */
public class InsufficientBalanceException extends RuntimeException {
    public InsufficientBalanceException(String message) {
        super(message);
    }
}
