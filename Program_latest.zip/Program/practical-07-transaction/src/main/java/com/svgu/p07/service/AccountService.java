package com.svgu.p07.service;

import com.svgu.p07.entity.Account;

public interface AccountService {
    Account create(Account account);
    void transferFunds(int fromId, int toId, double amount);
    Account getAccount(int id);
    Account updateHolder(int id, String accountHolder);
    void closeAccount(int id);
}
