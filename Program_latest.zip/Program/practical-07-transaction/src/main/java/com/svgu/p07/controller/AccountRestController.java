package com.svgu.p07.controller;

import com.svgu.p07.entity.Account;
import com.svgu.p07.exception.InsufficientBalanceException;
import com.svgu.p07.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Bank fund transfer. Controller calls the service only.
 *   POST   /api/accounts            -> 201 Created
 *   POST   /api/accounts/transfer   -> 200 OK or 409 Conflict (rollback)
 *   GET    /api/accounts/{id}       -> 200 OK
 *   PUT    /api/accounts/{id}       -> 200 OK
 *   DELETE /api/accounts/{id}       -> 204 No Content or 400 Bad Request
 */
@RestController
@RequestMapping("/api/accounts")
public class AccountRestController {

    @Autowired
    private AccountService accountService;

    @PostMapping
    public ResponseEntity<Account> create(@RequestBody Account account) {
        return ResponseEntity.status(HttpStatus.CREATED).body(accountService.create(account));
    }

    @PostMapping("/transfer")
    public ResponseEntity<String> transfer(@RequestBody TransferRequest request) {
        try {
            accountService.transferFunds(request.getFromId(), request.getToId(), request.getAmount());
            return ResponseEntity.ok("Transfer successful");
        } catch (InsufficientBalanceException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Account> get(@PathVariable int id) {
        Account account = accountService.getAccount(id);
        if (account == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(account);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Account> update(@PathVariable int id, @RequestBody Account body) {
        return ResponseEntity.ok(accountService.updateHolder(id, body.getAccountHolder()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> close(@PathVariable int id) {
        try {
            accountService.closeAccount(id);
            return ResponseEntity.noContent().build();
        } catch (InsufficientBalanceException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    // simple request object for the transfer body
    public static class TransferRequest {
        private int fromId;
        private int toId;
        private double amount;

        public int getFromId() { return fromId; }
        public void setFromId(int fromId) { this.fromId = fromId; }
        public int getToId() { return toId; }
        public void setToId(int toId) { this.toId = toId; }
        public double getAmount() { return amount; }
        public void setAmount(double amount) { this.amount = amount; }
    }
}
