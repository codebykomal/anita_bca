package com.svgu.p07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 7: Transaction Management with @Transactional - Bank Fund Transfer.
 */
@SpringBootApplication
public class Practical07Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical07Application.class, args);
    }
}
