package com.svgu.p07.service.impl;

import com.svgu.p07.entity.Account;
import com.svgu.p07.exception.InsufficientBalanceException;
import com.svgu.p07.repository.AccountRepository;
import com.svgu.p07.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * transferFunds is @Transactional: if balance goes below zero after the debit,
 * InsufficientBalanceException is thrown and the whole transaction rolls back.
 */
@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Override
    public Account create(Account account) {
        return accountRepository.save(account);
    }

    @Override
    @Transactional
    public void transferFunds(int fromId, int toId, double amount) {
        Account from = accountRepository.findById(fromId).orElse(null);
        Account to = accountRepository.findById(toId).orElse(null);

        // debit the source account
        from.setBalance(from.getBalance() - amount);
        accountRepository.save(from);

        // check AFTER debit so rollback can be demonstrated
        if (from.getBalance() < 0) {
            throw new InsufficientBalanceException(
                    "Insufficient balance in account " + fromId + ". Transaction rolled back.");
        }

        // credit the destination account
        to.setBalance(to.getBalance() + amount);
        accountRepository.save(to);
    }

    @Override
    public Account getAccount(int id) {
        return accountRepository.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public Account updateHolder(int id, String accountHolder) {
        Account account = accountRepository.findById(id).orElse(null);
        account.setAccountHolder(accountHolder);
        return accountRepository.save(account);
    }

    @Override
    @Transactional
    public void closeAccount(int id) {
        Account account = accountRepository.findById(id).orElse(null);
        if (account.getBalance() != 0) {
            throw new InsufficientBalanceException(
                    "Cannot close account " + id + " with non-zero balance.");
        }
        accountRepository.delete(account);
    }
}
