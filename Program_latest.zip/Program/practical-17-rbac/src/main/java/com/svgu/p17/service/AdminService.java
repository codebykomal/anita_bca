package com.svgu.p17.service;

import com.svgu.p17.entity.AdminItem;

import java.util.List;

public interface AdminService {
    List<AdminItem> getAll();
    AdminItem create(AdminItem item);
    AdminItem update(int id, AdminItem item);
    boolean delete(int id);
}
