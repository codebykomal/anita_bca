package com.svgu.p17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 17: Role-Based Access Control (RBAC) with Spring Security.
 */
@SpringBootApplication
public class Practical17Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical17Application.class, args);
    }
}
