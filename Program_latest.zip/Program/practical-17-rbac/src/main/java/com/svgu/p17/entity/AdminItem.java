package com.svgu.p17.entity;

/** Simple POJO stored in an in-memory list inside the service. */
public class AdminItem {

    private int id;
    private String label;

    public AdminItem() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
}
