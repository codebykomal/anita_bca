package com.svgu.p17.service.impl;

import com.svgu.p17.entity.AdminItem;
import com.svgu.p17.service.AdminService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {

    private List<AdminItem> items = new ArrayList<>();
    private int nextId = 1;

    @Override
    public List<AdminItem> getAll() {
        return items;
    }

    @Override
    public AdminItem create(AdminItem item) {
        item.setId(nextId);
        nextId++;
        items.add(item);
        return item;
    }

    @Override
    public AdminItem update(int id, AdminItem updated) {
        for (AdminItem item : items) {
            if (item.getId() == id) {
                item.setLabel(updated.getLabel());
                return item;
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        return items.removeIf(item -> item.getId() == id);
    }
}
