package com.svgu.p17.controller;

import com.svgu.p17.entity.AdminItem;
import com.svgu.p17.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Role-based authorization with @PreAuthorize. Controller calls the service only.
 *   GET    /api/admin/data        ADMIN only  -> 200 OK (403 for USER)
 *   POST   /api/admin/data        ADMIN only  -> 201 Created
 *   PUT    /api/admin/data/{id}   ADMIN only  -> 200 OK
 *   DELETE /api/admin/data/{id}   ADMIN only  -> 204 No Content
 *   GET    /api/user/data         ADMIN or USER -> 200 OK
 */
@RestController
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/api/admin/data")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<AdminItem>> getAdminData() {
        return ResponseEntity.ok(adminService.getAll());
    }

    @PostMapping("/api/admin/data")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AdminItem> create(@RequestBody AdminItem item) {
        return ResponseEntity.status(HttpStatus.CREATED).body(adminService.create(item));
    }

    @PutMapping("/api/admin/data/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AdminItem> update(@PathVariable int id, @RequestBody AdminItem updated) {
        AdminItem item = adminService.update(id, updated);
        if (item == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(item);
    }

    @DeleteMapping("/api/admin/data/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = adminService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/api/user/data")
    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<String> getUserData() {
        return ResponseEntity.ok("Accessible to both USER and ADMIN roles.");
    }
}
