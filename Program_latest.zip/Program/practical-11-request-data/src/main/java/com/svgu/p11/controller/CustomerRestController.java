package com.svgu.p11.controller;

import com.svgu.p11.entity.Customer;
import com.svgu.p11.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Three ways to receive client input. Controller calls the service only.
 *   GET    /api/customers/{id}                       @PathVariable
 *   GET    /api/customers/search?city=..&minAge=..   @RequestParam
 *   POST   /api/customers                            @RequestBody -> 201
 *   PUT    /api/customers/{id}                        @PathVariable + @RequestBody
 *   DELETE /api/customers/{id}                        @PathVariable -> 204
 */
@RestController
@RequestMapping("/api/customers")
public class CustomerRestController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getById(@PathVariable int id) {
        Customer customer = customerService.getById(id);
        if (customer == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(customer);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Customer>> search(@RequestParam String city,
                                 @RequestParam(required = false, defaultValue = "0") int minAge) {
        return ResponseEntity.ok(customerService.search(city, minAge));
    }

    @PostMapping
    public ResponseEntity<Customer> create(@RequestBody Customer customer) {
        return ResponseEntity.status(HttpStatus.CREATED).body(customerService.create(customer));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> update(@PathVariable int id, @RequestBody Customer updated) {
        Customer customer = customerService.update(id, updated);
        if (customer == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(customer);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = customerService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
