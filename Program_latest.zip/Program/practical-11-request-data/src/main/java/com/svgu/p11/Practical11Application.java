package com.svgu.p11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 11: Handling Request Data - @PathVariable, @RequestParam, @RequestBody.
 */
@SpringBootApplication
public class Practical11Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical11Application.class, args);
    }
}
