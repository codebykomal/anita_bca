package com.svgu.p11.repository;

import com.svgu.p11.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    List<Customer> findByCityAndAgeGreaterThanEqual(String city, int minAge);
}
