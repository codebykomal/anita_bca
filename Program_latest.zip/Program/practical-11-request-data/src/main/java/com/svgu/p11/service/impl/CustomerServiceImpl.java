package com.svgu.p11.service.impl;

import com.svgu.p11.entity.Customer;
import com.svgu.p11.repository.CustomerRepository;
import com.svgu.p11.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer getById(int id) {
        return customerRepository.findById(id).orElse(null);
    }

    @Override
    public List<Customer> search(String city, int minAge) {
        return customerRepository.findByCityAndAgeGreaterThanEqual(city, minAge);
    }

    @Override
    public Customer create(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public Customer update(int id, Customer updated) {
        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer == null) {
            return null;
        }
        customer.setName(updated.getName());
        customer.setCity(updated.getCity());
        customer.setAge(updated.getAge());
        return customerRepository.save(customer);
    }

    @Override
    public boolean delete(int id) {
        if (!customerRepository.existsById(id)) {
            return false;
        }
        customerRepository.deleteById(id);
        return true;
    }
}
