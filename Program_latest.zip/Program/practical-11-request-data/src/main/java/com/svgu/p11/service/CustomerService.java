package com.svgu.p11.service;

import com.svgu.p11.entity.Customer;

import java.util.List;

public interface CustomerService {
    Customer getById(int id);
    List<Customer> search(String city, int minAge);
    Customer create(Customer customer);
    Customer update(int id, Customer customer);
    boolean delete(int id);
}
