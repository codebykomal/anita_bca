package com.svgu.p18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 18: Securing REST API as an OAuth2 Resource Server with JWT.
 */
@SpringBootApplication
public class Practical18Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical18Application.class, args);
    }
}
