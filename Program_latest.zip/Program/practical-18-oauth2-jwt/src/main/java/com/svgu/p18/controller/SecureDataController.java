package com.svgu.p18.controller;

import com.svgu.p18.entity.Note;
import com.svgu.p18.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Endpoints protected by JWT (need a valid Bearer token). Controller calls service only.
 *   GET    /api/secure/data        -> 200 OK
 *   POST   /api/secure/data        -> 201 Created
 *   PUT    /api/secure/data/{id}   -> 200 OK
 *   DELETE /api/secure/data/{id}   -> 204 No Content
 */
@RestController
@RequestMapping("/api/secure/data")
public class SecureDataController {

    @Autowired
    private NoteService noteService;

    @GetMapping
    public ResponseEntity<List<Note>> getSecureData() {
        return ResponseEntity.ok(noteService.getAll());
    }

    @PostMapping
    public ResponseEntity<Note> create(@RequestBody Note note) {
        return ResponseEntity.status(HttpStatus.CREATED).body(noteService.create(note));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Note> update(@PathVariable int id, @RequestBody Note updated) {
        Note note = noteService.update(id, updated);
        if (note == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(note);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = noteService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
