package com.svgu.p10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 10: Layered Microservice Architecture - Controller + Service + Repository.
 */
@SpringBootApplication
public class Practical10Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical10Application.class, args);
    }
}
