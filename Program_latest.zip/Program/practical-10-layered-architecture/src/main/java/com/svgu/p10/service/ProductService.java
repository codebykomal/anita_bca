package com.svgu.p10.service;

import com.svgu.p10.entity.Product;

import java.util.List;

/** Service interface (business layer contract). */
public interface ProductService {
    Product create(Product product);
    List<Product> getAll();
    Product getById(int id);
    Product update(int id, Product product);
    boolean delete(int id);
}
