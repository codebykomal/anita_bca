package com.svgu.p01.service;

import com.svgu.p01.entity.Employee;

import java.util.List;

/**
 * Service layer: business contract (interface).
 */
public interface EmployeeService {
    Employee create(Employee employee);
    List<Employee> getAll();
    Employee getById(int id);
    Employee update(int id, Employee employee);
    boolean delete(int id);
}
