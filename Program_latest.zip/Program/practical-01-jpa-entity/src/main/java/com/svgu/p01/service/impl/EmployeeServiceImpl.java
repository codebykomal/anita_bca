package com.svgu.p01.service.impl;

import com.svgu.p01.entity.Employee;
import com.svgu.p01.repository.EmployeeRepository;
import com.svgu.p01.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Service implementation layer: holds business logic and talks to the repository.
 * The controller never touches the repository directly.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Employee create(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public List<Employee> getAll() {
        List<Employee> list = new ArrayList<>();
        for (Employee e : employeeRepository.findAll()) {
            list.add(e);
        }
        return list;
    }

    @Override
    public Employee getById(int id) {
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public Employee update(int id, Employee updated) {
        Employee employee = employeeRepository.findById(id).orElse(null);
        if (employee == null) {
            return null;
        }
        employee.setEmpName(updated.getEmpName());
        employee.setDepartment(updated.getDepartment());
        employee.setSalary(updated.getSalary());
        return employeeRepository.save(employee);
    }

    @Override
    public boolean delete(int id) {
        if (!employeeRepository.existsById(id)) {
            return false;
        }
        employeeRepository.deleteById(id);
        return true;
    }
}
