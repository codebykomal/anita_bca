package com.svgu.p01.repository;

import com.svgu.p01.entity.Employee;
import org.springframework.data.repository.CrudRepository;

/**
 * Repository layer: base Spring Data repository.
 * Inherited: save(), findAll(), findById(), deleteById().
 */
public interface EmployeeRepository extends CrudRepository<Employee, Integer> {
}
