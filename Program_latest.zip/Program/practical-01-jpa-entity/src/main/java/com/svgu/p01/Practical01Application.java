package com.svgu.p01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 1: Introduction to JPA - Entity Class and Persisting a Single Entity.
 */
@SpringBootApplication
public class Practical01Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical01Application.class, args);
    }
}
