package com.svgu.p06.controller;

import com.svgu.p06.entity.Course;
import com.svgu.p06.entity.Student;
import com.svgu.p06.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

/**
 * Course side of Many-to-Many. Controller calls the service only.
 *   POST   /api/courses                 -> 201 Created
 *   GET    /api/courses/{id}/students   -> 200 OK
 *   PUT    /api/courses/{id}
 *   DELETE /api/courses/{id}            -> 204
 */
@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping
    public ResponseEntity<Course> create(@RequestBody Course course) {
        return ResponseEntity.status(HttpStatus.CREATED).body(courseService.create(course));
    }

    @GetMapping("/{id}/students")
    public ResponseEntity<Set<Student>> courseStudents(@PathVariable int id) {
        Set<Student> students = courseService.getStudents(id);
        if (students == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(students);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Course> update(@PathVariable int id, @RequestBody Course updated) {
        Course course = courseService.update(id, updated);
        if (course == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(course);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = courseService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
