package com.svgu.p06.service.impl;

import com.svgu.p06.entity.Course;
import com.svgu.p06.entity.Student;
import com.svgu.p06.repository.CourseRepository;
import com.svgu.p06.repository.StudentRepository;
import com.svgu.p06.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public Course create(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public Set<Student> getStudents(int courseId) {
        Course course = courseRepository.findById(courseId).orElse(null);
        if (course == null) {
            return null;
        }
        return course.getStudents();
    }

    @Override
    public Course update(int id, Course updated) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return null;
        }
        course.setCourseName(updated.getCourseName());
        return courseRepository.save(course);
    }

    @Override
    public boolean delete(int id) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return false;
        }
        // remove this course from every student first
        for (Student s : course.getStudents()) {
            s.getCourses().remove(course);
            studentRepository.save(s);
        }
        courseRepository.delete(course);
        return true;
    }
}
