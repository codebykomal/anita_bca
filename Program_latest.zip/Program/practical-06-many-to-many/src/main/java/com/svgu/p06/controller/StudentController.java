package com.svgu.p06.controller;

import com.svgu.p06.entity.Student;
import com.svgu.p06.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Student side of Many-to-Many. Controller calls the service only.
 *   POST   /api/students                                 -> 201 Created
 *   POST   /api/students/{id}/enroll/{courseId}          -> 200 OK
 *   GET    /api/students/{id}
 *   PUT    /api/students/{id}
 *   DELETE /api/students/{studentId}/unenroll/{courseId} -> 204
 */
@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping
    public ResponseEntity<Student> create(@RequestBody Student student) {
        return ResponseEntity.status(HttpStatus.CREATED).body(studentService.create(student));
    }

    @PostMapping("/{id}/enroll/{courseId}")
    public ResponseEntity<Student> enroll(@PathVariable int id, @PathVariable int courseId) {
        Student student = studentService.enroll(id, courseId);
        if (student == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(student);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudent(@PathVariable int id) {
        Student student = studentService.getById(id);
        if (student == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(student);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Student> update(@PathVariable int id, @RequestBody Student updated) {
        Student student = studentService.update(id, updated);
        if (student == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(student);
    }

    @DeleteMapping("/{studentId}/unenroll/{courseId}")
    public ResponseEntity<Void> unenroll(@PathVariable int studentId, @PathVariable int courseId) {
        boolean done = studentService.unenroll(studentId, courseId);
        if (!done) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
