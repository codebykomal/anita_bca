package com.svgu.p06.service;

import com.svgu.p06.entity.Course;
import com.svgu.p06.entity.Student;

import java.util.Set;

public interface CourseService {
    Course create(Course course);
    Set<Student> getStudents(int courseId);
    Course update(int id, Course course);
    boolean delete(int id);
}
