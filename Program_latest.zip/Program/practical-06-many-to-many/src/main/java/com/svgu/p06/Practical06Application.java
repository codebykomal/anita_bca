package com.svgu.p06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 6: Many-to-Many Mapping - Student and Course.
 */
@SpringBootApplication
public class Practical06Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical06Application.class, args);
    }
}
