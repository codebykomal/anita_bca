package com.svgu.p06.service.impl;

import com.svgu.p06.entity.Course;
import com.svgu.p06.entity.Student;
import com.svgu.p06.repository.CourseRepository;
import com.svgu.p06.repository.StudentRepository;
import com.svgu.p06.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public Student create(Student student) {
        // attach existing courses by their id
        Set<Course> courses = new HashSet<>();
        for (Course c : student.getCourses()) {
            Course existing = courseRepository.findById(c.getCourseId()).orElse(null);
            if (existing != null) {
                courses.add(existing);
            }
        }
        student.setCourses(courses);
        return studentRepository.save(student);
    }

    @Override
    public Student enroll(int studentId, int courseId) {
        Student student = studentRepository.findById(studentId).orElse(null);
        Course course = courseRepository.findById(courseId).orElse(null);
        if (student == null || course == null) {
            return null;
        }
        student.getCourses().add(course);
        return studentRepository.save(student);
    }

    @Override
    public Student getById(int id) {
        return studentRepository.findById(id).orElse(null);
    }

    @Override
    public Student update(int id, Student updated) {
        Student student = studentRepository.findById(id).orElse(null);
        if (student == null) {
            return null;
        }
        student.setStudentName(updated.getStudentName());
        return studentRepository.save(student);
    }

    @Override
    public boolean unenroll(int studentId, int courseId) {
        Student student = studentRepository.findById(studentId).orElse(null);
        if (student == null) {
            return false;
        }
        student.getCourses().removeIf(c -> c.getCourseId() == courseId);
        studentRepository.save(student);
        return true;
    }
}
