package com.svgu.p06.service;

import com.svgu.p06.entity.Student;

public interface StudentService {
    Student create(Student student);
    Student enroll(int studentId, int courseId);
    Student getById(int id);
    Student update(int id, Student student);
    boolean unenroll(int studentId, int courseId);
}
