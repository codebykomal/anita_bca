package com.svgu.p15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 15: Securing REST API with HTTP Basic Authentication.
 */
@SpringBootApplication
public class Practical15Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical15Application.class, args);
    }
}
