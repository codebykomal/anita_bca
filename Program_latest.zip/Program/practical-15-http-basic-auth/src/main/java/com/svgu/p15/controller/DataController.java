package com.svgu.p15.controller;

import com.svgu.p15.entity.Note;
import com.svgu.p15.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Public + secured endpoints. Controller calls the service only.
 *   GET    /api/public/data         (open, no login)       -> 200 OK
 *   GET    /api/secure/data         (needs Basic Auth)     -> 200 OK
 *   POST   /api/secure/data         (needs Basic Auth)     -> 201 Created
 *   PUT    /api/secure/data/{id}    (needs Basic Auth)     -> 200 OK
 *   DELETE /api/secure/data/{id}    (needs Basic Auth)     -> 204 No Content
 */
@RestController
public class DataController {

    @Autowired
    private NoteService noteService;

    @GetMapping("/api/public/data")
    public ResponseEntity<String> publicData() {
        return ResponseEntity.ok("This is PUBLIC data - accessible without login.");
    }

    @GetMapping("/api/secure/data")
    public ResponseEntity<List<Note>> secureData() {
        return ResponseEntity.ok(noteService.getAll());
    }

    @PostMapping("/api/secure/data")
    public ResponseEntity<Note> create(@RequestBody Note note) {
        return ResponseEntity.status(HttpStatus.CREATED).body(noteService.create(note));
    }

    @PutMapping("/api/secure/data/{id}")
    public ResponseEntity<Note> update(@PathVariable int id, @RequestBody Note updated) {
        Note note = noteService.update(id, updated);
        if (note == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(note);
    }

    @DeleteMapping("/api/secure/data/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = noteService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
