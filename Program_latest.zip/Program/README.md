# Spring Boot Practical Assignment — 20 Separate Projects

MCA Semester III — Advance Java Programming (Spring Boot).
Har practical ek alag, complete, standalone Spring Boot project hai.

## Projects Index

| No. | Folder | Topic |
|-----|--------|-------|
| 1 | practical-01-jpa-entity | JPA Entity + CrudRepository (Employee) |
| 2 | practical-02-repository-hierarchy | CrudRepository vs PagingAndSorting vs JpaRepository (Product) |
| 3 | practical-03-custom-queries | findBy, countBy, @Query JPQL (Employee) |
| 4 | practical-04-one-to-one | One-to-One: User-Profile, Employee-Passport, Country-Capital |
| 5 | practical-05-one-to-many | One-to-Many / Many-to-One (Department-Employee) |
| 6 | practical-06-many-to-many | Many-to-Many (Student-Course) |
| 7 | practical-07-transaction | @Transactional bank fund transfer |
| 8 | practical-08-pagination-sorting | Pageable / PageRequest |
| 9 | practical-09-rest-responseentity | @RestController + ResponseEntity (Book) |
| 10 | practical-10-layered-architecture | Controller + Service + Repository (Product) |
| 11 | practical-11-request-data | @PathVariable, @RequestParam, @RequestBody (Customer) |
| 12 | practical-12-dto-pattern | DTO pattern hiding password (Employee) |
| 13 | practical-13-validation | Bean Validation @Valid (Customer) |
| 14 | practical-14-exception-handling | @ControllerAdvice global exception handler |
| 15 | practical-15-http-basic-auth | HTTP Basic Authentication |
| 16 | practical-16-registration-login | Registration/Login with BCrypt (DB-backed) |
| 17 | practical-17-rbac | Role-Based Access Control (@PreAuthorize) |
| 18 | practical-18-oauth2-jwt | OAuth2 Resource Server with JWT |
| 19 | practical-19-oauth2-login | OAuth2 Login (Google/GitHub) |
| 20 | practical-20-cors | CORS configuration for secured APIs |

## How to run any project

Har project ke folder me jaakar (jahan uska `pom.xml` hai):

```bash
mvn spring-boot:run
```

Ya pehle build karke jar chalao:

```bash
mvn clean package
java -jar target/<artifact-name>-1.0.0.jar
```

App default `http://localhost:8080` par chalti hai. Ek time par ek hi project
chalao (sabhi port 8080 use karte hain), ya alag port ke liye run karte waqt
`--server.port=8081` pass karo.

## Database

- Default: **H2 in-memory** (kuch install karne ki zarurat nahi).
- H2 console: `http://localhost:8080/h2-console`
  (JDBC URL jaise `jdbc:h2:mem:p1db`, user `sa`, blank password).
- **MySQL** use karna ho to har project ke `application.properties` me MySQL
  wali lines uncomment kar do aur H2 wali comment kar do.

## Security practicals ke default credentials

- Practical 15: `user` / `user123`
- Practical 16: pehle `POST /api/auth/register` se user banao, phir login
- Practical 17: `admin` / `admin123` (ADMIN), `user` / `user123` (USER)
- Practical 20: `user` / `user123`

## Code level

Saara code **beginner-friendly** style me likha hai, par PDF ke hisaab se
`ResponseEntity` use kiya hai (proper HTTP status codes ke liye):
- Field injection `@Autowired` (constructor ki jagah) — padhne me aasaan.
- Simple `if-else` aur `for` loops (advanced stream/Optional chains nahi).
- Har controller `ResponseEntity` return karta hai taaki PDF ki testing table ke
  status codes (201 Created, 200 OK, 204 No Content, 404 Not Found) sahi aayein.

## Notes

- **Practical 18 (JWT):** chalane ke liye `application.properties` me
  `spring.security.oauth2.resourceserver.jwt.issuer-uri` set karna ZAROORI hai
  (apne Authorization Server ka URL). Uske bina JWT decoder nahi banta.
- **Practical 19 (OAuth2 Login):** chalane ke liye `application.properties` me
  Google/GitHub ka `client-id` aur `client-secret` daalna ZAROORI hai. Phir
  browser me `http://localhost:8080/oauth2/authorization/google` kholo.
