package com.svgu.p12.service;

import com.svgu.p12.dto.EmployeeDTO;

import java.util.List;

public interface EmployeeService {
    EmployeeDTO create(EmployeeDTO dto);
    List<EmployeeDTO> getAll();
    EmployeeDTO getById(int id);
    EmployeeDTO update(int id, EmployeeDTO dto);
    boolean delete(int id);
}
