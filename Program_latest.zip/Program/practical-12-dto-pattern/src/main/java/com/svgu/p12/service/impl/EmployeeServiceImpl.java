package com.svgu.p12.service.impl;

import com.svgu.p12.dto.EmployeeDTO;
import com.svgu.p12.dto.EmployeeMapper;
import com.svgu.p12.entity.Employee;
import com.svgu.p12.repository.EmployeeRepository;
import com.svgu.p12.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public EmployeeDTO create(EmployeeDTO dto) {
        Employee entity = EmployeeMapper.toEntity(dto);
        entity.setPassword("default-secret"); // set on server, not from client
        Employee saved = employeeRepository.save(entity);
        return EmployeeMapper.toDto(saved);
    }

    @Override
    public List<EmployeeDTO> getAll() {
        List<EmployeeDTO> result = new ArrayList<>();
        for (Employee e : employeeRepository.findAll()) {
            result.add(EmployeeMapper.toDto(e));
        }
        return result;
    }

    @Override
    public EmployeeDTO getById(int id) {
        Employee employee = employeeRepository.findById(id).orElse(null);
        if (employee == null) {
            return null;
        }
        return EmployeeMapper.toDto(employee);
    }

    @Override
    public EmployeeDTO update(int id, EmployeeDTO dto) {
        Employee employee = employeeRepository.findById(id).orElse(null);
        if (employee == null) {
            return null;
        }
        // update only safe fields, password stays the same
        employee.setEmpName(dto.getEmpName());
        employee.setDepartment(dto.getDepartment());
        Employee saved = employeeRepository.save(employee);
        return EmployeeMapper.toDto(saved);
    }

    @Override
    public boolean delete(int id) {
        if (!employeeRepository.existsById(id)) {
            return false;
        }
        employeeRepository.deleteById(id);
        return true;
    }
}
