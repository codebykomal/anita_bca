package com.svgu.p12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 12: DTO Pattern - Separating the Entity from the API Contract.
 */
@SpringBootApplication
public class Practical12Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical12Application.class, args);
    }
}
