package com.svgu.p12.dto;

/** DTO containing only fields safe to expose (no password). */
public class EmployeeDTO {

    private int empId;
    private String empName;
    private String department;

    public EmployeeDTO() {
    }

    public int getEmpId() { return empId; }
    public void setEmpId(int empId) { this.empId = empId; }
    public String getEmpName() { return empName; }
    public void setEmpName(String empName) { this.empName = empName; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
}
