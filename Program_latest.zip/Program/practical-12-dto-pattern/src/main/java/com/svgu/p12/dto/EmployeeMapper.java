package com.svgu.p12.dto;

import com.svgu.p12.entity.Employee;

/** Static mapping utility between Entity and DTO. */
public class EmployeeMapper {

    public static EmployeeDTO toDto(Employee e) {
        if (e == null) return null;
        EmployeeDTO dto = new EmployeeDTO();
        dto.setEmpId(e.getEmpId());
        dto.setEmpName(e.getEmpName());
        dto.setDepartment(e.getDepartment());
        return dto;
    }

    public static Employee toEntity(EmployeeDTO d) {
        if (d == null) return null;
        Employee e = new Employee();
        e.setEmpId(d.getEmpId());
        e.setEmpName(d.getEmpName());
        e.setDepartment(d.getDepartment());
        return e;
    }
}
