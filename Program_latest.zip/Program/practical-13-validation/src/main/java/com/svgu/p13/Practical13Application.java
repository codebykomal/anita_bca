package com.svgu.p13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 13: Request Validation using Bean Validation (@Valid).
 */
@SpringBootApplication
public class Practical13Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical13Application.class, args);
    }
}
