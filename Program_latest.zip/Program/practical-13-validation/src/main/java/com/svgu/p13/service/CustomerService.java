package com.svgu.p13.service;

import com.svgu.p13.entity.Customer;

public interface CustomerService {
    Customer create(Customer customer);
    Customer getById(int id);
    Customer update(int id, Customer customer);
    boolean delete(int id);
}
