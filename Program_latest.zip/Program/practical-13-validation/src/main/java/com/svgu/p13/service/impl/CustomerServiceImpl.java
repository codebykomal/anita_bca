package com.svgu.p13.service.impl;

import com.svgu.p13.entity.Customer;
import com.svgu.p13.repository.CustomerRepository;
import com.svgu.p13.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer create(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public Customer getById(int id) {
        return customerRepository.findById(id).orElse(null);
    }

    @Override
    public Customer update(int id, Customer updated) {
        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer == null) {
            return null;
        }
        customer.setName(updated.getName());
        customer.setEmail(updated.getEmail());
        customer.setAge(updated.getAge());
        return customerRepository.save(customer);
    }

    @Override
    public boolean delete(int id) {
        if (!customerRepository.existsById(id)) {
            return false;
        }
        customerRepository.deleteById(id);
        return true;
    }
}
