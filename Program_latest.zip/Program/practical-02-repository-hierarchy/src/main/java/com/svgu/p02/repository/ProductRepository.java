package com.svgu.p02.repository;

import com.svgu.p02.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository layer - top of the Spring Data hierarchy (JpaRepository),
 * so methods from all three levels are available:
 *   CrudRepository            -> save, findById, findAll, deleteById
 *   PagingAndSortingRepository -> findAll(Sort), findAll(Pageable)
 *   JpaRepository             -> saveAll (batch), flush, saveAndFlush
 */
public interface ProductRepository extends JpaRepository<Product, Integer> {
}
