package com.svgu.p02.service.impl;

import com.svgu.p02.entity.Product;
import com.svgu.p02.repository.ProductRepository;
import com.svgu.p02.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    // JpaRepository specific: batch insert then flush
    @Override
    public List<Product> saveBatch(List<Product> products) {
        List<Product> saved = productRepository.saveAll(products);
        productRepository.flush();
        return saved;
    }

    // CrudRepository.findAll()
    @Override
    public List<Product> getAll() {
        return productRepository.findAll();
    }

    // PagingAndSortingRepository.findAll(Sort)
    @Override
    public List<Product> getSorted(String sortBy) {
        return productRepository.findAll(Sort.by(sortBy));
    }

    @Override
    public Product create(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Product update(int id, Product updated) {
        Product product = productRepository.findById(id).orElse(null);
        if (product == null) {
            return null;
        }
        product.setProductName(updated.getProductName());
        product.setCategory(updated.getCategory());
        product.setPrice(updated.getPrice());
        product.setQuantity(updated.getQuantity());
        return productRepository.save(product);
    }

    @Override
    public boolean delete(int id) {
        if (!productRepository.existsById(id)) {
            return false;
        }
        productRepository.deleteById(id);
        return true;
    }
}
