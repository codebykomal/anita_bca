package com.svgu.p02.controller;

import com.svgu.p02.entity.Product;
import com.svgu.p02.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller layer: calls the service only.
 *   POST   /api/products/batch   -> saveAll() + flush()  (JpaRepository)
 *   GET    /api/products         -> findAll()            (CrudRepository)
 *   GET    /api/products/sorted  -> findAll(Sort)        (PagingAndSorting)
 *   POST   /api/products
 *   PUT    /api/products/{id}
 *   DELETE /api/products/{id}
 */
@RestController
@RequestMapping("/api/products")
public class ProductRestController {

    @Autowired
    private ProductService productService;

    @PostMapping("/batch")
    public ResponseEntity<List<Product>> saveBatch(@RequestBody List<Product> products) {
        List<Product> saved = productService.saveBatch(products);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAll() {
        return ResponseEntity.ok(productService.getAll());
    }

    @GetMapping("/sorted")
    public ResponseEntity<List<Product>> getSorted(@RequestParam(defaultValue = "price") String sortBy) {
        return ResponseEntity.ok(productService.getSorted(sortBy));
    }

    @PostMapping
    public ResponseEntity<Product> create(@RequestBody Product product) {
        Product saved = productService.create(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> update(@PathVariable int id, @RequestBody Product updated) {
        Product product = productService.update(id, updated);
        if (product == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(product);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = productService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
