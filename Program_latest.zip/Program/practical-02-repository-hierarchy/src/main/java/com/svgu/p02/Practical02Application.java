package com.svgu.p02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 2: Spring Data Repository Hierarchy.
 */
@SpringBootApplication
public class Practical02Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical02Application.class, args);
    }
}
