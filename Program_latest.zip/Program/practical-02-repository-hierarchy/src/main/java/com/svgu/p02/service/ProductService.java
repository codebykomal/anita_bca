package com.svgu.p02.service;

import com.svgu.p02.entity.Product;

import java.util.List;

public interface ProductService {
    List<Product> saveBatch(List<Product> products);
    List<Product> getAll();
    List<Product> getSorted(String sortBy);
    Product create(Product product);
    Product update(int id, Product product);
    boolean delete(int id);
}
