package com.svgu.p20.service;

import com.svgu.p20.entity.Note;

import java.util.List;

public interface NoteService {
    List<Note> getAll();
    Note create(Note note);
    Note update(int id, Note note);
    boolean delete(int id);
}
