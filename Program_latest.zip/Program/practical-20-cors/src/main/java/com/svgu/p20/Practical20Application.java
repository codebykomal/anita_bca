package com.svgu.p20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 20: CORS Configuration for Secured REST APIs.
 */
@SpringBootApplication
public class Practical20Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical20Application.class, args);
    }
}
