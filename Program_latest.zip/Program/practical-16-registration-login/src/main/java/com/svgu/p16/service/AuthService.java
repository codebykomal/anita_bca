package com.svgu.p16.service;

import com.svgu.p16.entity.AppUser;

public interface AuthService {
    AppUser register(AppUser appUser);
    AppUser updateProfile(String username, AppUser updated);
    boolean deregister(String username);
}
