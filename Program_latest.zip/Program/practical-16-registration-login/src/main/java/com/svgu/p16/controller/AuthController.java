package com.svgu.p16.controller;

import com.svgu.p16.entity.AppUser;
import com.svgu.p16.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

/**
 * Controller calls the AuthService only.
 *   POST   /api/auth/register       (open)        -> 201 Created
 *   GET    /api/secure/data         (needs login) -> 200 OK
 *   PUT    /api/auth/profile        (needs login) -> 200 OK
 *   DELETE /api/auth/deregister     (needs login) -> 204 No Content
 */
@RestController
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/api/auth/register")
    public ResponseEntity<AppUser> register(@RequestBody AppUser appUser) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.register(appUser));
    }

    @GetMapping("/api/secure/data")
    public ResponseEntity<String> secureData(Authentication authentication) {
        return ResponseEntity.ok("Authenticated as: " + authentication.getName());
    }

    @PutMapping("/api/auth/profile")
    public ResponseEntity<AppUser> updateProfile(Authentication authentication,
                                                 @RequestBody AppUser updated) {
        AppUser user = authService.updateProfile(authentication.getName(), updated);
        if (user == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(user);
    }

    @DeleteMapping("/api/auth/deregister")
    public ResponseEntity<Void> deregister(Authentication authentication) {
        boolean done = authService.deregister(authentication.getName());
        if (!done) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
