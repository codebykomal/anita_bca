package com.svgu.p16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 16: User Registration and Login with BCrypt Password Encoding.
 */
@SpringBootApplication
public class Practical16Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical16Application.class, args);
    }
}
