package com.svgu.p16.service.impl;

import com.svgu.p16.entity.AppUser;
import com.svgu.p16.repository.AppUserRepository;
import com.svgu.p16.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private AppUserRepository appUserRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public AppUser register(AppUser appUser) {
        // encode plain password into a BCrypt hash before saving
        String hashed = passwordEncoder.encode(appUser.getPassword());
        appUser.setPassword(hashed);
        if (appUser.getRole() == null) {
            appUser.setRole("USER");
        }
        return appUserRepository.save(appUser);
    }

    @Override
    public AppUser updateProfile(String username, AppUser updated) {
        AppUser user = appUserRepository.findByUsername(username).orElse(null);
        if (user == null) {
            return null;
        }
        if (updated.getRole() != null) {
            user.setRole(updated.getRole());
        }
        return appUserRepository.save(user);
    }

    @Override
    public boolean deregister(String username) {
        AppUser user = appUserRepository.findByUsername(username).orElse(null);
        if (user == null) {
            return false;
        }
        appUserRepository.delete(user);
        return true;
    }
}
