package com.svgu.p19.service;

import com.svgu.p19.entity.Note;

public interface NoteService {
    Note create(Note note);
    Note update(int id, Note note);
    boolean delete(int id);
}
