package com.svgu.p19.service.impl;

import com.svgu.p19.entity.Note;
import com.svgu.p19.service.NoteService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class NoteServiceImpl implements NoteService {

    private List<Note> notes = new ArrayList<>();
    private int nextId = 1;

    @Override
    public Note create(Note note) {
        note.setId(nextId);
        nextId++;
        notes.add(note);
        return note;
    }

    @Override
    public Note update(int id, Note updated) {
        for (Note note : notes) {
            if (note.getId() == id) {
                note.setText(updated.getText());
                return note;
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        return notes.removeIf(note -> note.getId() == id);
    }
}
