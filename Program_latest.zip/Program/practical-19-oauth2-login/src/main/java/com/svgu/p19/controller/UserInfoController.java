package com.svgu.p19.controller;

import com.svgu.p19.entity.Note;
import com.svgu.p19.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Reads the logged-in OAuth2 user. Controller calls the service for notes.
 *   GET    /api/user/profile      -> 200 OK (name + email)
 *   POST   /api/user/notes        -> 201 Created
 *   PUT    /api/user/notes/{id}   -> 200 OK
 *   DELETE /api/user/notes/{id}   -> 204 No Content
 */
@RestController
@RequestMapping("/api/user")
public class UserInfoController {

    @Autowired
    private NoteService noteService;

    @GetMapping("/profile")
    public ResponseEntity<Map<String, Object>> getUserProfile(@AuthenticationPrincipal OAuth2User principal) {
        Map<String, Object> result = new HashMap<>();
        if (principal != null) {
            result.put("name", principal.getAttribute("name"));
            result.put("email", principal.getAttribute("email"));
        }
        return ResponseEntity.ok(result);
    }

    @PostMapping("/notes")
    public ResponseEntity<Note> create(@RequestBody Note note) {
        return ResponseEntity.status(HttpStatus.CREATED).body(noteService.create(note));
    }

    @PutMapping("/notes/{id}")
    public ResponseEntity<Note> update(@PathVariable int id, @RequestBody Note updated) {
        Note note = noteService.update(id, updated);
        if (note == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(note);
    }

    @DeleteMapping("/notes/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = noteService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
