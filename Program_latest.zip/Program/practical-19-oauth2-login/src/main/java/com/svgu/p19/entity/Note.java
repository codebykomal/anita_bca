package com.svgu.p19.entity;

/** Simple POJO stored in an in-memory list inside the service. */
public class Note {

    private int id;
    private String text;

    public Note() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
}
