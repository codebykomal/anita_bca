package com.svgu.p19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 19: OAuth2 Login with a Third-Party Provider (Google/GitHub).
 */
@SpringBootApplication
public class Practical19Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical19Application.class, args);
    }
}
