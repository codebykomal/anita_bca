package com.svgu.p19.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Config layer: OAuth2 Login with Google/GitHub.
 *
 * IMPORTANT: Set client-id and client-secret in application.properties.
 * Then open this URL in a browser to login:
 *   http://localhost:8080/oauth2/authorization/google
 * After login, /api/user/** endpoints become accessible.
 */
@Configuration
public class OAuth2LoginConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(auth -> auth
                .requestMatchers("/oauth2/**", "/login/**").permitAll()
                .anyRequest().authenticated()
        );
        http.oauth2Login(Customizer.withDefaults());
        return http.build();
    }
}
