package com.svgu.p03.service.impl;

import com.svgu.p03.entity.Employee;
import com.svgu.p03.repository.EmployeeRepository;
import com.svgu.p03.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Employee create(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public List<Employee> findByDepartment(String dept) {
        return employeeRepository.findByDepartment(dept);
    }

    @Override
    public long countByDepartment(String dept) {
        return employeeRepository.countByDepartment(dept);
    }

    @Override
    public List<Employee> findBySalaryAbove(double salary) {
        return employeeRepository.findBySalaryGreaterThan(salary);
    }

    @Override
    public List<Employee> findBySalaryRange(double min, double max) {
        return employeeRepository.findBySalaryRange(min, max);
    }

    @Override
    public Employee update(int id, Employee updated) {
        Employee employee = employeeRepository.findById(id).orElse(null);
        if (employee == null) {
            return null;
        }
        employee.setEmpName(updated.getEmpName());
        employee.setDepartment(updated.getDepartment());
        employee.setSalary(updated.getSalary());
        return employeeRepository.save(employee);
    }

    @Override
    public boolean delete(int id) {
        if (!employeeRepository.existsById(id)) {
            return false;
        }
        employeeRepository.deleteById(id);
        return true;
    }
}
