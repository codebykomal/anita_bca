package com.svgu.p03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Practical 3: Custom Query Methods - findBy, countBy and @Query (JPQL).
 */
@SpringBootApplication
public class Practical03Application {
    public static void main(String[] args) {
        SpringApplication.run(Practical03Application.class, args);
    }
}
