package com.svgu.p03.controller;

import com.svgu.p03.entity.Employee;
import com.svgu.p03.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller layer: calls the service only.
 *   POST   /api/employees
 *   GET    /api/employees/department/{dept}
 *   GET    /api/employees/count/{dept}
 *   GET    /api/employees/salaryabove?salary=..
 *   GET    /api/employees/salaryrange?min=&max=
 *   PUT    /api/employees/{id}
 *   DELETE /api/employees/{id}
 */
@RestController
@RequestMapping("/api/employees")
public class EmployeeRestController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping
    public ResponseEntity<Employee> create(@RequestBody Employee employee) {
        Employee saved = employeeService.create(employee);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @GetMapping("/department/{dept}")
    public ResponseEntity<List<Employee>> byDepartment(@PathVariable String dept) {
        return ResponseEntity.ok(employeeService.findByDepartment(dept));
    }

    @GetMapping("/count/{dept}")
    public ResponseEntity<Long> countByDepartment(@PathVariable String dept) {
        return ResponseEntity.ok(employeeService.countByDepartment(dept));
    }

    @GetMapping("/salaryabove")
    public ResponseEntity<List<Employee>> salaryAbove(@RequestParam double salary) {
        return ResponseEntity.ok(employeeService.findBySalaryAbove(salary));
    }

    @GetMapping("/salaryrange")
    public ResponseEntity<List<Employee>> salaryRange(@RequestParam double min, @RequestParam double max) {
        return ResponseEntity.ok(employeeService.findBySalaryRange(min, max));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employee> update(@PathVariable int id, @RequestBody Employee updated) {
        Employee employee = employeeService.update(id, updated);
        if (employee == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(employee);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        boolean deleted = employeeService.delete(id);
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}
