package com.svgu.p03.service;

import com.svgu.p03.entity.Employee;

import java.util.List;

public interface EmployeeService {
    Employee create(Employee employee);
    List<Employee> findByDepartment(String dept);
    long countByDepartment(String dept);
    List<Employee> findBySalaryAbove(double salary);
    List<Employee> findBySalaryRange(double min, double max);
    Employee update(int id, Employee employee);
    boolean delete(int id);
}
